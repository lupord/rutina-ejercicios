
import React from "react";

const rutina = [
  {
    dia: "Día 1 – Piernas y Empuje",
    ejercicios: [
      {
        nombre: "Sentadilla con barra",
        series: "3 series x 8–12 reps",
        descripcion:
          "Ejercicio básico para cuádriceps, glúteos y core. Mantén la espalda recta y baja hasta que tus muslos estén paralelos al suelo."
      },
      {
        nombre: "Press de pecho con mancuernas",
        series: "3 x 8–12 reps",
        descripcion:
          "Empuja dos mancuernas desde el pecho sobre un banco plano. Trabaja pectorales, hombros y tríceps."
      },
      {
        nombre: "Remo con mancuerna a una mano",
        series: "3 x 10 por lado",
        descripcion:
          "Apoya una rodilla en un banco, y tira la mancuerna hacia tu cadera. Fortalece dorsales y bíceps."
      },
      {
        nombre: "Hip thrust",
        series: "3 x 10–15 reps",
        descripcion:
          "Con la espalda alta apoyada en un banco, eleva la cadera apretando glúteos. Trabaja glúteos e isquiotibiales."
      },
      {
        nombre: "Plancha abdominal",
        series: "3 x 30 segundos",
        descripcion:
          "Apoya antebrazos y pies formando línea recta. Contrae el core y evita que la cadera se hunda o suba demasiado."
      }
    ]
  },
  {
    dia: "Día 2 – Espalda y Tracción",
    ejercicios: [
      {
        nombre: "Peso muerto con barra hexagonal",
        series: "3 x 8–10 reps",
        descripcion:
          "Levanta la barra desde el suelo extendiendo caderas y rodillas. Trabaja glúteos, isquios y espalda baja."
      },
      {
        nombre: "Press militar con mancuernas",
        series: "3 x 8–10 reps",
        descripcion:
          "Desde la altura de los hombros, empuja las mancuernas sobre tu cabeza. Fortalece hombros y tríceps."
      },
      {
        nombre: "Jalón en polea al pecho",
        series: "3 x 8–12 reps",
        descripcion:
          "Tira de la barra hacia el pecho desde una polea alta. Trabaja dorsales, bíceps y espalda media."
      },
      {
        nombre: "Zancadas con mancuernas",
        series: "3 x 10 pasos por pierna",
        descripcion:
          "Da un paso largo, baja controladamente y vuelve a subir. Trabaja cuádriceps, glúteos y equilibrio."
      },
      {
        nombre: "Curl de bíceps",
        series: "2–3 x 12–15 reps",
        descripcion:
          "Flexiona los codos llevando la carga hacia tus hombros. Aísla el trabajo en bíceps."
      }
    ]
  },
  {
    dia: "Día 3 – Tren Inferior y Combinados",
    ejercicios: [
      {
        nombre: "Prensa de piernas",
        series: "3 x 10–12 reps",
        descripcion:
          "Empuja la plataforma con ambos pies. Trabaja cuádriceps y glúteos sin sobrecargar la espalda."
      },
      {
        nombre: "Press inclinado con mancuernas",
        series: "3 x 8–12 reps",
        descripcion:
          "Empuja las mancuernas en banco inclinado. Énfasis en pectoral superior y hombros frontales."
      },
      {
        nombre: "Remo en polea baja",
        series: "3 x 10–12 reps",
        descripcion:
          "Tira el mango hacia el ombligo desde la polea baja. Fortalece la espalda media y bíceps."
      },
      {
        nombre: "Peso muerto rumano",
        series: "3 x 10 reps",
        descripcion:
          "Desliza mancuernas por tus piernas con la espalda recta. Trabaja isquios y glúteos."
      },
      {
        nombre: "Plancha lateral",
        series: "3 x 20–30 segundos por lado",
        descripcion:
          "Sostén el cuerpo de lado apoyando antebrazo y pies. Trabaja oblicuos y core lateral."
      }
    ]
  }
];

export default function App() {
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Rutina de Gimnasio para Mujeres (3 Días)</h1>
      {rutina.map((dia, idx) => (
        <div key={idx} className="mb-6">
          <h2 className="text-xl font-semibold mb-2">{dia.dia}</h2>
          <ul className="space-y-2">
            {dia.ejercicios.map((e, i) => (
              <li key={i} className="border p-4 rounded-xl shadow">
                <h3 className="font-bold">{e.nombre} <span className="font-normal">({e.series})</span></h3>
                <p>{e.descripcion}</p>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}
